// $(document).ready(function(){
  $("#home_modate").click(function(){
    alert("hello");
  });
// });
