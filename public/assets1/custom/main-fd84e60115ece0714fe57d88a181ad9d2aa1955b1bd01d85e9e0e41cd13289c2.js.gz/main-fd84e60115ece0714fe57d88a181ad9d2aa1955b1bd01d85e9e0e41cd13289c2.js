// $(document).ready(function(){
  $("#home_modate_click").click(function(){
    alert("hello");
  });
// });
